<!--
 * @Author: winbin
 * @Date: 2022-04-24 23:52:53
 * @LastEditors: winbin
 * @LastEditTime: 2022-04-24 23:52:53
 * @FilePath: \uni_tpl\src\components\common\chat.vue
-->
<template>
    <view class="chat">
        
    </view>
</template>