<template>
	<view class="container account_login">
		<view class="left-bottom-sign"></view>
		<!-- <view class="back-btn newfont icon-Chevron-Left" @click="navBack"></view> -->
		<view class="right-top-sign"></view>
		<view class="wrapper">
      		<view class="top-sign-title">该项目为测试项目（用于演示或测试）</view>
			<view class="left-top-sign">LOGIN</view>
			<view class="welcome">
				欢迎回来！
			</view>
			<view class="input-content">
				<view class="input-item">
					<text class="tit">用户名</text>
					<input type="text" v-model="form.username" placeholder="请输入用户名" maxlength="11"
						data-key="username" />
				</view>
				<view class="input-item">
					<text class="tit">密码</text>
					<input type="password" v-model="form.password" placeholder="5-16位不含特殊字符的数字、字母组合"
						placeholder-class="input-empty" maxlength="20" password data-key="password" @confirm="login" />
				</view>
			</view>
			<button class="confirm-btn" @click="login" :disabled="logining">登录</button>
			<view class="forget-section">
				<navigator url="./forgot">忘记密码?</navigator>
			</view>
			<view class="Authorization-page"  style="width: 100%; display: flex; justify-content: center; ">
				<view class="Author" style=" width: 100upx; height: 110upx; ">
					<button  class="Author-qier" @click="Tencent">

					</button>
				</view>
				<view class="Author" style=" width: 100upx; height: 110upx;">
					<button class="Author-weixin" @click="weixin">

					</button>
				</view>
				<view class="Author" style=" width: 100upx; height: 110upx;">
					<button  class="Author-weibo" @click="weibo">

					</button>
				</view>
			</view>
		</view>
		<view class="register-section">
			还没有账号?<navigator url="./register" class="text">马上注册</navigator>
		</view>
		<view v-if="openFace" class="face-login">
			<!-- #ifdef MP-WEIXIN || H5 -->
			<button @click="openAndInitCamera()">摄像头</button>
			<button @click="openAndUploadImg()">图片</button>
			<!-- #endif -->
			<!-- #ifdef APP-VUE -->
			<button @click="openAndInitCamera()">人脸识别</button>
			<!-- #endif -->
			<view v-if="openCamera" class="face-camera">
				<!-- #ifdef MP-WEIXIN || H5 -->
				<view>
					<!-- #ifdef MP-WEIXIN -->
					<camera device-position="front" flash="off" @error="cameraError" style="width: 100%; height: 300px;"></camera>
					<image v-if="form['face_image']" :src="$fullUrl(form['face_image'])" />
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<video id="videoElement" ref="videoElement" autoplay></video>
					<canvas ref="canvasElement" canvas-id="canvasElement"></canvas>
					<!-- #endif -->
				</view>
				<button @click="takePhoto">拍照</button>
				<!-- #endif -->
				<!-- #ifdef APP-VUE -->
				<view>
					<image v-if="form['face_image']" :src="$fullUrl(form['face_image'])" />
				</view>
				<!-- #endif -->
				<button @click="submitFace('camera')">提交</button>
			</view>
			<view v-if="openFaceImg" class="face-img">
				<view class="diy_field diy_img" v-if="form['face_image']" @click="change_img('face_image')">
					<image :src="$fullUrl(form['face_image'])" />
				</view>
				<view v-else class="btn_add_img" @click="change_img('face_image')" style="width: 300px;height: 300px">
					<text>+</text>
				</view>
				<button @click="submitFace('img')">提交</button>
			</view>
		</view>
	</view>
</template>


<script>
	import mixin from "@/libs/mixins/page.js";

	export default {
		mixins: [mixin],
		data() {
			return {
				logining: false,
				form: {
					username: "",
					password: "",
					face_image:""
				},
				rules: {
					username: {
						rules: [{
								required: true,
								errorMessage: "请输入用户名",
							},
							{
								minLength: 5,
								maxLength: 16,
								errorMessage: "用户名长度在 {minLength} 到 {maxLength} 个字符",
							},
						],
					},
					password: {
						rules: [{
								required: true,
								errorMessage: "请输入密码",
							},
							{
								minLength: 5,
								maxLength: 16,
								errorMessage: "密码长度在 {minLength} 到 {maxLength} 个字符",
							},
						],
					},
				},
				openFace: false,
				openCamera:false,
				openFaceImg:false,
				// 媒体流，用于关闭摄像头
				mediaStreamTrack: null,
			};
		},
		methods: {
			login() {
				this.logining = true;
				let form = Object.assign({}, this.form);
				//人脸识别登录
				this.$post("~/api/user/login?", form, (res) => {
					if (res.result && res.result.obj) {
						this.openFace = true;
					} else if (res.error) {
						this.$toast(res.error.message, "error");
					}
					this.logining = false;
				});
			},
			initCamera() {
				// #ifdef H5
				const self = this;
				// 注意本例需要在HTTPS协议网站中运行，新版本Chrome中getUserMedia接口在http下不再支持。

				// 老的浏览器可能根本没有实现 mediaDevices，所以我们可以先设置一个空的对象
				if (navigator.mediaDevices === undefined) {
					navigator.mediaDevices = {};
				}

				// 一些浏览器部分支持 mediaDevices。我们不能直接给对象设置 getUserMedia
				// 因为这样可能会覆盖已有的属性。这里我们只会在没有getUserMedia属性的时候添加它。
				if (navigator.mediaDevices.getUserMedia === undefined) {
					navigator.mediaDevices.getUserMedia = function (constraints) {
						// 首先，如果有getUserMedia的话，就获得它
						const getUserMedia =
								navigator.getUserMedia ||
								navigator.webkitGetUserMedia ||
								navigator.mozGetUserMedia;

						// 一些浏览器根本没实现它 - 那么就返回一个error到promise的reject来保持一个统一的接口
						if (!getUserMedia) {
							return Promise.reject(
									new Error("无法访问摄像头")
							);
						}
						// 否则，为老的navigator.getUserMedia方法包裹一个Promise
						return new Promise(function (resolve, reject) {
							getUserMedia.call(navigator, constraints, resolve, reject);
						});
					};
				}

				uni.getSystemInfo({
					success: function (res) {
						const constraints = {
							audio: false,
							video: {
								// 前置摄像头
								facingMode: "user",
								// 手机端相当于高
								width: Math.max(res.windowWidth, res.windowHeight) - 120,
								// 手机端相当于宽
								height: Math.min(res.windowWidth, res.windowHeight),
							},
						};

						navigator.mediaDevices
								.getUserMedia(constraints)
								.then(function (stream) {
									self.mediaStreamTrack = stream;

									const video = document.querySelector("video");
									// 旧的浏览器可能没有srcObject
									if ("srcObject" in video) {
										video.srcObject = stream;
									} else {
										// 防止在新的浏览器里使用它，应为它已经不再支持了
										video.src = window.URL.createObjectURL(stream);
									}
									video.onloadedmetadata = function (e) {
										video.play();
									};
								})
								.catch(function (err) {
									console.log(err.name + ": " + err.message);
								});
					},
				});
				// #endif
				// #ifdef APP-VUE
				let self = this;
				uni.chooseImage({
					count: 1, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album','camera'], //从相册选择
					success: function (res) {
						const uploadTask = uni.uploadFile({
							url: self.$fullUrl('/api/user/upload?'),
							filePath: res.tempFilePaths[0],
							name: 'file',
							formData: {},
							header: {
								'x-auth-token': self.$store.state.user.token
							},
							success: function(uploadFileRes) {
								let filename = JSON.parse(uploadFileRes.data).result.url
								self.form['face_image'] = filename
							}
						});

						uploadTask.onProgressUpdate(function(res) {
							self.percent = res.progress;
							console.log('上传进度' + res.progress);
							console.log('已经上传的数据长度' + res.totalBytesSent);
							console.log('预期需要上传的数据总长度' + res.totalBytesExpectedToSend);
						});
					}
				});
				// #endif
			},
			takePhoto() {
				// #ifdef MP-WEIXIN
				const ctx = uni.createCameraContext();
				let _self = this;
				ctx.takePhoto({
					quality: 'high',
					success: (res) => {
						const tempImagePath = res.tempImagePath;
						const uploadTask = uni.uploadFile({
							url: _self.$fullUrl('/api/user/upload?'),
							filePath: tempImagePath,
							name: 'file',
							formData: {},
							header: {
								'x-auth-token': _self.$store.state.user.token
							},
							success: function(uploadFileRes) {
								let filename = JSON.parse(uploadFileRes.data).result.url
								_self.form['face_image'] = filename
							}
						});

						uploadTask.onProgressUpdate(function(res) {
							_self.percent = res.progress;
							console.log('上传进度' + res.progress);
							console.log('已经上传的数据长度' + res.totalBytesSent);
							console.log('预期需要上传的数据总长度' + res.totalBytesExpectedToSend);
						});
					}
				});
				// #endif
				// #ifdef H5
				const videoElement = document.querySelector("video")
				const canvasElement = document.querySelector("canvas");
				const context = canvasElement.getContext('2d');

				// 将视频流的画面绘制到Canvas中
				context.drawImage(videoElement, 0, 0, 300, 150);

				// 获取Canvas中的图像数据
				const imageData = canvasElement.toDataURL('image/png');
				let file = this.base64ToFile(imageData,'cameraImg')
				let _self = this;
				uni.uploadFile({
					url: _self.$fullUrl('/api/user/upload?'),
					file: file,
					name: 'file',
					formData: {
					},
					header: {
						'x-auth-token': _self.$store.state.user.token
					},
					success: function(uploadFileRes) {
						let filename = JSON.parse(uploadFileRes.data).result.url
						_self.form['face_image'] = filename
					},
					error: function (e){
						console.log(e)
					}
				});
				// #endif
			},
			closeVideo() {
				if (this.mediaStreamTrack) {
					// 关闭摄像头
					this.mediaStreamTrack.getTracks().forEach(function (track) {
						track.stop();
					});
					this.mediaStreamTrack = null;
				}
			},
			/**
			 * 上传图片
			 * @param {Object} param文件参数
			 */
			change_img(key_name){
				let _self = this;
				// 选择图像方法
				uni.chooseImage({
					count: 1,
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success: function(res) {
						const tempFilePaths = res.tempFilePaths;
						const uploadTask = uni.uploadFile({
							url: _self.$fullUrl('/api/user/upload?'),
							filePath: tempFilePaths[0],
							name: 'file',
							formData: {},
							header: {
								'x-auth-token': _self.$store.state.user.token
							},
							success: function(uploadFileRes) {
								let filename = JSON.parse(uploadFileRes.data).result.url
								_self.form[key_name] = filename
							}
						});

						uploadTask.onProgressUpdate(function(res) {
							_self.percent = res.progress;
							console.log('上传进度' + res.progress);
							console.log('已经上传的数据长度' + res.totalBytesSent);
							console.log('预期需要上传的数据总长度' + res.totalBytesExpectedToSend);
						});
					},
					error: function(e) {
						console.log(e);
					}
				});
			},
			openAndInitCamera(){
				this.openFaceImg = false;
				this.openCamera = true;
				this.initCamera();
			},
			openAndUploadImg(){
				this.openCamera = false;
				this.openFaceImg = true;
			},
			submitFace(type){
				// #ifdef H5
				if (type==='camera'){
					this.closeVideo();
				}
				// #endif
				//人脸识别登录
				let _this = this;
				this.$post('~/api/user/face_login?', _this.form, (res) => {
					if (res.result && res.result.obj) {
						let obj = res.result.obj;
						// 缓存token
						uni.db.set("token", obj.token);
						// 存储用户信息
						this.$store.commit("user_set", obj);
						// 获取权限集
						this.$get_auth(this.user.user_group);
						// 前往首页
						this.$nav("/pages/index/index");
					} else if (res.error) {
						this.$toast(res.error.message, "error");
					}
				});
			},
			//base64转flie
			base64ToFile(base64, name) {
				if (typeof base64 != 'string') {
					return;
				}
				let arr = base64.split(',')
				let type = arr[0].match(/:(.*?);/)[1]
				let fileExt = type.split('/')[1]
				let bstr = atob(arr[1])
				let n = bstr.length
				let u8arr = new Uint8Array(n)
				while (n--) {
					u8arr[n] = bstr.charCodeAt(n)
				}
				return new File([u8arr], `${name}.` + fileExt, {
					type: type
				})
			},
			cameraError(e){
				console.log(e.detail);
			},
			/**
			 * 手动重置表单
			 */
			resetForm() {
				this.$refs.form.resetFields();
			},
			// 三个授权组件地址
			Tencent(){
				uni.navigateTo({
					url:'../authorization/authorization?id=1'
				})
			},
			weixin(){
				uni.navigateTo({
					url:'../authorization/authorization-weixin?id=2'
				})
			},
			weibo(){
				uni.navigateTo({
					url:'../authorization/authorization-weibo?id=3'
				})
			}
		},
		onBackPress() {
			var bl = false;
			var user_id = this.user.user_id;
			if (user_id == null || user_id < 1) {
				// this.$nav('/pages/index/index');
				bl = true;
			}
			return false;
		},
	};
</script>

<style lang="scss">
	page {
		background: #fff;
	}

	.container {
		padding-top: 115px;
		position: relative;
		width: 100vw;
		height: 100vh;
		overflow: hidden;
		background: #fff;
		box-sizing: border-box;
	}

	.wrapper {
		position: relative;
		z-index: 90;
		background: #fff;
		padding-bottom: 40upx;
	}

	.back-btn {
		position: absolute;
		left: 40upx;
		z-index: 9999;
		padding-top: var(--status-bar-height);
		top: 40upx;
		font-size: 40upx;
		color: $font-color-dark;
	}

	.left-top-sign {
		font-size: 120upx;
		color: $page-color-base;
		position: relative;
		left: -16upx;
	}

	.right-top-sign {
		position: absolute;
		top: 80upx;
		right: -30upx;
		z-index: 95;

		&:before,
		&:after {
			display: block;
			content: "";
			width: 400upx;
			height: 80upx;
			background: #b4f3e2;
		}

		&:before {
			transform: rotate(50deg);
			border-radius: 0 50px 0 0;
		}

		&:after {
			position: absolute;
			right: -198upx;
			top: 0;
			transform: rotate(-50deg);
			border-radius: 50px 0 0 0;
			/* background: pink; */
		}
	}

	.left-bottom-sign {
		position: absolute;
		left: -270upx;
		bottom: -320upx;
		border: 100upx solid #d0d1fd;
		border-radius: 50%;
		padding: 180upx;
	}

	.welcome {
		position: relative;
		left: 50upx;
		top: -90upx;
		font-size: 46upx;
		color: #555;
		text-shadow: 1px 0px 1px rgba(0, 0, 0, .3);
	}

	.input-content {
		padding: 0 60upx;
	}

	.input-item {
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: center;
		padding: 0 30upx;
		background: $page-color-light;
		height: 120upx;
		border-radius: 4px;
		margin-bottom: 50upx;

		&:last-child {
			margin-bottom: 0;
		}

		.tit {
			height: 50upx;
			line-height: 56upx;
			font-size: $font-sm+2upx;
			color: $font-color-base;
		}

		input {
			height: 60upx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			width: 100%;
		}
	}

	.confirm-btn {
		width: 630upx;
		height: 76upx;
		line-height: 76upx;
		border-radius: 50px;
		margin-top: 70upx;
		background: $uni-color-primary;
		color: #fff;
		font-size: $font-lg;

		&:after {
			border-radius: 100px;
		}
	}

	.forget-section {
		font-size: $font-sm+2upx;
		color: $font-color-spec;
		text-align: center;
		margin-top: 40upx;
	}

	.register-section {
		position: absolute;
		left: 0;
		bottom: 50upx;
		width: 100%;
		font-size: $font-sm+2upx;
		color: $font-color-base;
		text-align: center;

		.text {
			display: inline-block;
			color: $font-color-spec;
			margin-left: 10upx;
		}
	}
</style>
